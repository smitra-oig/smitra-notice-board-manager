<?php
/**
 * Meta Boxes
 *
 * Registers and handles notice meta fields in the admin editor.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Meta_Boxes
 *
 * @since 1.0.0
 */
class ANBMWP_Meta_Boxes {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'add_meta_boxes',           array( __CLASS__, 'register' ) );
		add_action( 'save_post_anbmwp_notice',  array( __CLASS__, 'save' ) );
		add_action( 'admin_head',               array( __CLASS__, 'hide_unnecessary_ui' ) );
		add_action( 'admin_enqueue_scripts',    array( __CLASS__, 'enqueue_scripts' ) );
	}

	/**
	 * Enqueue admin scripts for media uploader.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 */
	public static function enqueue_scripts( $hook ) {
		global $post_type;
		if ( 'anbmwp_notice' !== $post_type ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script(
			'anbmwp-admin-meta',
			ANBMWP_PLUGIN_URL . 'assets/js/admin-meta.js',
			array( 'jquery', 'media-upload' ),
			ANBMWP_VERSION,
			true
		);
	}

	/**
	 * Register meta box.
	 *
	 * @since 1.0.0
	 */
	public static function register() {
		add_meta_box(
			'anbmwp_notice_details',
			__( 'Notice Details', 'smitra-notice-board-manager' ),
			array( __CLASS__, 'render' ),
			'anbmwp_notice',
			'normal',
			'high'
		);
	}

	/**
	 * Render meta box content.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Current post object.
	 */
	public static function render( $post ) {
		wp_nonce_field( 'anbmwp_save_meta', 'anbmwp_meta_nonce' );

		$short_summary  = get_post_meta( $post->ID, '_anbmwp_short_summary', true );
		$attachment     = get_post_meta( $post->ID, '_anbmwp_attachment', true );
		$external_link  = get_post_meta( $post->ID, '_anbmwp_external_link', true );
		$link_btn_text  = get_post_meta( $post->ID, '_anbmwp_link_btn_text', true );
		$expiry_date    = get_post_meta( $post->ID, '_anbmwp_expiry_date', true );
		$pinned         = get_post_meta( $post->ID, '_anbmwp_pinned', true );
		$urgent         = get_post_meta( $post->ID, '_anbmwp_urgent', true );
		$login_required = get_post_meta( $post->ID, '_anbmwp_login_required', true );
		?>
		<table class="anbmwp-meta-table">
			<tr>
				<td>
					<label for="anbmwp_short_summary"><?php esc_html_e( 'Short Summary', 'smitra-notice-board-manager' ); ?></label>
					<br><small><?php esc_html_e( 'Used for notice listing preview', 'smitra-notice-board-manager' ); ?></small>
				</td>
				<td>
					<textarea id="anbmwp_short_summary" name="anbmwp_short_summary"
						placeholder="<?php esc_attr_e( 'Brief description shown in notice listings...', 'smitra-notice-board-manager' ); ?>"><?php echo esc_textarea( $short_summary ); ?></textarea>
				</td>
			</tr>
			<tr>
				<td>
					<label for="anbmwp_attachment"><?php esc_html_e( 'Attachment (PDF)', 'smitra-notice-board-manager' ); ?></label>
					<br><small><?php esc_html_e( 'URL to PDF or document', 'smitra-notice-board-manager' ); ?></small>
				</td>
				<td>
					<input type="text" id="anbmwp_attachment" name="anbmwp_attachment"
						value="<?php echo esc_url( $attachment ); ?>" placeholder="https://" />
					<button type="button" class="button anbmwp-upload-btn" data-target="anbmwp_attachment">
						<?php esc_html_e( 'Upload / Select File', 'smitra-notice-board-manager' ); ?>
					</button>
				</td>
			</tr>
			<tr>
				<td>
					<label for="anbmwp_external_link"><?php esc_html_e( 'External Link', 'smitra-notice-board-manager' ); ?></label>
					<br><small><?php esc_html_e( 'Opens in a new tab on the frontend', 'smitra-notice-board-manager' ); ?></small>
				</td>
				<td>
					<input type="text" id="anbmwp_external_link" name="anbmwp_external_link"
						value="<?php echo esc_url( $external_link ); ?>" placeholder="https://" />
				</td>
			</tr>
			<tr>
				<td>
					<label for="anbmwp_link_btn_text"><?php esc_html_e( 'External Link Button Text', 'smitra-notice-board-manager' ); ?></label>
					<br><small><?php esc_html_e( 'Label shown on the external link button. Default: "Learn More"', 'smitra-notice-board-manager' ); ?></small>
				</td>
				<td>
					<input type="text" id="anbmwp_link_btn_text" name="anbmwp_link_btn_text"
						value="<?php echo esc_attr( $link_btn_text ); ?>" placeholder="<?php esc_attr_e( 'Learn More', 'smitra-notice-board-manager' ); ?>" />
				</td>
			</tr>
			<tr>
				<td>
					<label for="anbmwp_expiry_date"><?php esc_html_e( 'Expiry Date', 'smitra-notice-board-manager' ); ?></label>
					<br><small><?php esc_html_e( 'Notice hides after this date', 'smitra-notice-board-manager' ); ?></small>
				</td>
				<td>
					<input type="date" id="anbmwp_expiry_date" name="anbmwp_expiry_date"
						value="<?php echo esc_attr( $expiry_date ); ?>" />
				</td>
			</tr>
		</table>

		<div class="anbmwp-flag-row">
			<label>
				<input type="checkbox" name="anbmwp_pinned" value="1" <?php checked( $pinned, '1' ); ?> />
				<span class="anbmwp-pin-badge">📌 PIN</span>
				<?php esc_html_e( 'Pin this notice to the top', 'smitra-notice-board-manager' ); ?>
			</label>
			<label>
				<input type="checkbox" name="anbmwp_urgent" value="1" <?php checked( $urgent, '1' ); ?> />
				<span class="anbmwp-urgent-badge">⚠ URGENT</span>
				<?php esc_html_e( 'Mark as urgent', 'smitra-notice-board-manager' ); ?>
			</label>
			<label>
				<input type="checkbox" name="anbmwp_login_required" value="1" <?php checked( $login_required, '1' ); ?> />
				<span class="anbmwp-lock-badge">🔒 MEMBERS ONLY</span>
				<?php esc_html_e( 'Restrict to logged-in users', 'smitra-notice-board-manager' ); ?>
			</label>
		</div>
		<?php
	}

	/**
	 * Save meta box values.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 */
	public static function save( $post_id ) {
		if ( ! isset( $_POST['anbmwp_meta_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['anbmwp_meta_nonce'] ) ), 'anbmwp_save_meta' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Text fields
		if ( isset( $_POST['anbmwp_short_summary'] ) ) {
			update_post_meta( $post_id, '_anbmwp_short_summary', sanitize_textarea_field( wp_unslash( $_POST['anbmwp_short_summary'] ) ) );
		}
		if ( isset( $_POST['anbmwp_attachment'] ) ) {
			update_post_meta( $post_id, '_anbmwp_attachment', esc_url_raw( wp_unslash( $_POST['anbmwp_attachment'] ) ) );
		}
		if ( isset( $_POST['anbmwp_external_link'] ) ) {
			update_post_meta( $post_id, '_anbmwp_external_link', esc_url_raw( wp_unslash( $_POST['anbmwp_external_link'] ) ) );
		}
		if ( isset( $_POST['anbmwp_link_btn_text'] ) ) {
			update_post_meta( $post_id, '_anbmwp_link_btn_text', sanitize_text_field( wp_unslash( $_POST['anbmwp_link_btn_text'] ) ) );
		}
		if ( isset( $_POST['anbmwp_expiry_date'] ) ) {
			update_post_meta( $post_id, '_anbmwp_expiry_date', sanitize_text_field( wp_unslash( $_POST['anbmwp_expiry_date'] ) ) );
		}

		// Checkboxes
		update_post_meta( $post_id, '_anbmwp_pinned',         isset( $_POST['anbmwp_pinned'] )         ? '1' : '0' );
		update_post_meta( $post_id, '_anbmwp_urgent',         isset( $_POST['anbmwp_urgent'] )         ? '1' : '0' );
		update_post_meta( $post_id, '_anbmwp_login_required', isset( $_POST['anbmwp_login_required'] ) ? '1' : '0' );
	}

	/**
	 * Hide unnecessary UI elements in notice editor.
	 *
	 * @since 1.0.0
	 */
	public static function hide_unnecessary_ui() {
		global $post_type;
		if ( 'anbmwp_notice' !== $post_type ) {
			return;
		}
		// Styles defined in admin CSS file
		wp_add_inline_style( 'anbmwp-admin', '#slugdiv, #authordiv, #commentstatusdiv, #trackbacksdiv, #postcustom { display: none !important; }' );
	}
}
