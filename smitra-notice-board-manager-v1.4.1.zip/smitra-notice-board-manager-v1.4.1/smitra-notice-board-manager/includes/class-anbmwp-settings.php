<?php
/**
 * Plugin Settings
 *
 * Handles the settings page and all plugin configuration options.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Settings
 *
 * @since 1.0.0
 */
class ANBMWP_Settings {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Add settings submenu.
	 *
	 * @since 1.0.0
	 */
	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=anbmwp_notice',
			__( 'Notice Board Settings', 'smitra-notice-board-manager' ),
			__( 'Settings', 'smitra-notice-board-manager' ),
			'manage_options',
			'anbmwp-settings',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register settings.
	 *
	 * @since 1.0.0
	 */
	public static function register_settings() {
		register_setting( 'anbmwp_settings_group', 'anbmwp_settings', array( __CLASS__, 'sanitize' ) );
	}

	/**
	 * Sanitize settings input.
	 *
	 * @since  1.0.0
	 * @param  array $input Raw input.
	 * @return array Sanitized values.
	 */
	public static function sanitize( $input ) {
		$clean = array();
		$clean['notices_per_page']     = intval( $input['notices_per_page'] ?? 10 );
		$clean['default_layout']       = in_array( $input['default_layout'] ?? 'list', array( 'list', 'grid' ), true ) ? $input['default_layout'] : 'list';
		$clean['show_search']          = ! empty( $input['show_search'] ) ? 1 : 0;
		$clean['view_all_text']        = sanitize_text_field( $input['view_all_text'] ?? 'View All Notices' );
		$clean['no_notices_text']      = sanitize_text_field( $input['no_notices_text'] ?? 'No notices found.' );
		$clean['back_button_text']     = sanitize_text_field( $input['back_button_text'] ?? '← Back to Notices' );
		$clean['back_button_url']      = esc_url_raw( $input['back_button_url'] ?? '' );
		$clean['notice_slug']          = sanitize_title( $input['notice_slug'] ?? 'notices' );
		$clean['category_slug']        = sanitize_title( $input['category_slug'] ?? 'notice-category' );
		$clean['tag_slug']             = sanitize_title( $input['tag_slug'] ?? 'notice-tag' );
		$clean['login_page_url']       = esc_url_raw( $input['login_page_url'] ?? '' );
		$clean['locked_message']       = sanitize_text_field( $input['locked_message'] ?? 'This notice is for members only. Please log in to view the full content.' );
		$clean['form_submission']      = in_array( $input['form_submission'] ?? 'draft', array( 'publish', 'draft' ), true ) ? $input['form_submission'] : 'draft';
		$clean['form_allowed_roles']   = isset( $input['form_allowed_roles'] ) && is_array( $input['form_allowed_roles'] )
			? array_map( 'sanitize_text_field', $input['form_allowed_roles'] )
			: array( 'administrator', 'editor' );
		$clean['form_success_message'] = sanitize_text_field( $input['form_success_message'] ?? 'Your notice has been submitted successfully.' );
		flush_rewrite_rules();
		return $clean;
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$options              = get_option( 'anbmwp_settings', array() );
		$notices_per_page     = $options['notices_per_page']     ?? 10;
		$default_layout       = $options['default_layout']       ?? 'list';
		$show_search          = $options['show_search']          ?? 1;
		$view_all_text        = $options['view_all_text']        ?? 'View All Notices';
		$no_notices_text      = $options['no_notices_text']      ?? 'No notices found.';
		$back_button_text     = $options['back_button_text']     ?? '← Back to Notices';
		$back_button_url      = $options['back_button_url']      ?? '';
		$notice_slug          = $options['notice_slug']          ?? 'notices';
		$category_slug        = $options['category_slug']        ?? 'notice-category';
		$tag_slug             = $options['tag_slug']             ?? 'notice-tag';
		$login_page_url       = $options['login_page_url']       ?? '';
		$locked_message       = $options['locked_message']       ?? 'This notice is for members only. Please log in to view the full content.';
		$form_submission      = $options['form_submission']      ?? 'draft';
		$form_allowed_roles   = $options['form_allowed_roles']   ?? array( 'administrator', 'editor' );
		$form_success_message = $options['form_success_message'] ?? 'Your notice has been submitted successfully.';
		$all_roles            = wp_roles()->roles;
		?>
		<div class="wrap">
			<h1>📋 <?php esc_html_e( 'Smitra Notice Board Manager — Settings', 'smitra-notice-board-manager' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'anbmwp_settings_group' ); ?>

				<h2><?php esc_html_e( '🔗 Slug Settings', 'smitra-notice-board-manager' ); ?></h2>
				<p style="color:#666;"><?php esc_html_e( 'After changing slugs, go to Settings → Permalinks and click Save to flush rewrite rules.', 'smitra-notice-board-manager' ); ?></p>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Notice Archive Slug', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<input type="text" name="anbmwp_settings[notice_slug]" value="<?php echo esc_attr( $notice_slug ); ?>" class="regular-text" />
							<p class="description"><?php echo esc_html( home_url( '/' . $notice_slug . '/' ) ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Category Slug', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<input type="text" name="anbmwp_settings[category_slug]" value="<?php echo esc_attr( $category_slug ); ?>" class="regular-text" />
							<p class="description"><?php echo esc_html( home_url( '/' . $category_slug . '/slug/' ) ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Tag Slug', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<input type="text" name="anbmwp_settings[tag_slug]" value="<?php echo esc_attr( $tag_slug ); ?>" class="regular-text" />
							<p class="description"><?php echo esc_html( home_url( '/' . $tag_slug . '/slug/' ) ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( '🔒 Content Restriction Settings', 'smitra-notice-board-manager' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Login Page URL', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<input type="text" name="anbmwp_settings[login_page_url]" value="<?php echo esc_attr( $login_page_url ); ?>" class="regular-text" placeholder="<?php echo esc_attr( home_url( '/login/' ) ); ?>" />
							<p class="description"><?php esc_html_e( 'Where guests are redirected when clicking "Log In to View". Leave empty to use default WordPress login.', 'smitra-notice-board-manager' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Locked Notice Message', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<input type="text" name="anbmwp_settings[locked_message]" value="<?php echo esc_attr( $locked_message ); ?>" class="large-text" />
							<p class="description"><?php esc_html_e( 'Message shown to guests on restricted notices.', 'smitra-notice-board-manager' ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( '⚙️ Display Settings', 'smitra-notice-board-manager' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Default Notices Per Page', 'smitra-notice-board-manager' ); ?></th>
						<td><input type="number" name="anbmwp_settings[notices_per_page]" value="<?php echo esc_attr( $notices_per_page ); ?>" min="1" max="100" class="small-text" /></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Default Layout', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<select name="anbmwp_settings[default_layout]">
								<option value="list" <?php selected( $default_layout, 'list' ); ?>><?php esc_html_e( 'List', 'smitra-notice-board-manager' ); ?></option>
								<option value="grid" <?php selected( $default_layout, 'grid' ); ?>><?php esc_html_e( 'Grid', 'smitra-notice-board-manager' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Show Search Bar', 'smitra-notice-board-manager' ); ?></th>
						<td><input type="checkbox" name="anbmwp_settings[show_search]" value="1" <?php checked( $show_search, 1 ); ?> /></td>
					</tr>
					<tr>
						<th><?php esc_html_e( '"View All" Button Text', 'smitra-notice-board-manager' ); ?></th>
						<td><input type="text" name="anbmwp_settings[view_all_text]" value="<?php echo esc_attr( $view_all_text ); ?>" class="regular-text" /></td>
					</tr>
					<tr>
						<th><?php esc_html_e( '"No Notices" Text', 'smitra-notice-board-manager' ); ?></th>
						<td><input type="text" name="anbmwp_settings[no_notices_text]" value="<?php echo esc_attr( $no_notices_text ); ?>" class="regular-text" /></td>
					</tr>
				</table>

				<h2><?php esc_html_e( '← Back Button Settings', 'smitra-notice-board-manager' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Back Button Text', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<input type="text" name="anbmwp_settings[back_button_text]" value="<?php echo esc_attr( $back_button_text ); ?>" class="regular-text" />
							<p class="description"><?php esc_html_e( 'Text shown on the back button on single notice pages.', 'smitra-notice-board-manager' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Back Button URL', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<input type="text" name="anbmwp_settings[back_button_url]" value="<?php echo esc_attr( $back_button_url ); ?>" class="regular-text" placeholder="<?php echo esc_attr( home_url( '/notices/' ) ); ?>" />
							<p class="description"><?php esc_html_e( 'Leave empty to use the default notices archive URL.', 'smitra-notice-board-manager' ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( '📝 Frontend Notice Form Settings', 'smitra-notice-board-manager' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Submission Mode', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<select name="anbmwp_settings[form_submission]">
								<option value="draft"   <?php selected( $form_submission, 'draft' );   ?>><?php esc_html_e( 'Save as Draft (Admin Approval Required)', 'smitra-notice-board-manager' ); ?></option>
								<option value="publish" <?php selected( $form_submission, 'publish' ); ?>><?php esc_html_e( 'Auto Publish Immediately', 'smitra-notice-board-manager' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Roles Allowed to Submit', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<?php foreach ( $all_roles as $role_key => $role_data ) : ?>
								<label style="display:block; margin-bottom:6px;">
									<input type="checkbox"
										name="anbmwp_settings[form_allowed_roles][]"
										value="<?php echo esc_attr( $role_key ); ?>"
										<?php checked( in_array( $role_key, (array) $form_allowed_roles, true ), true ); ?>
									/>
									<?php echo esc_html( translate_user_role( $role_data['name'] ) ); ?>
									<span style="color:#aaa; font-size:12px;">(<?php echo esc_html( $role_key ); ?>)</span>
								</label>
							<?php endforeach; ?>
							<p class="description"><?php esc_html_e( 'All current and future custom roles appear here automatically.', 'smitra-notice-board-manager' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Success Message', 'smitra-notice-board-manager' ); ?></th>
						<td>
							<input type="text" name="anbmwp_settings[form_success_message]" value="<?php echo esc_attr( $form_success_message ); ?>" class="large-text" />
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( '📌 Shortcode Reference', 'smitra-notice-board-manager' ); ?></h2>
				<table class="widefat striped" style="max-width:750px;">
					<thead><tr>
						<th><?php esc_html_e( 'Shortcode', 'smitra-notice-board-manager' ); ?></th>
						<th><?php esc_html_e( 'Description', 'smitra-notice-board-manager' ); ?></th>
					</tr></thead>
					<tbody>
						<tr><td><code>[noticeboard]</code></td><td><?php esc_html_e( 'Display all notices (default list view)', 'smitra-notice-board-manager' ); ?></td></tr>
						<tr><td><code>[noticeboard layout="grid"]</code></td><td><?php esc_html_e( 'Grid layout', 'smitra-notice-board-manager' ); ?></td></tr>
						<tr><td><code>[noticeboard posts="5"]</code></td><td><?php esc_html_e( 'Limit to 5 notices', 'smitra-notice-board-manager' ); ?></td></tr>
						<tr><td><code>[noticeboard category="slug"]</code></td><td><?php esc_html_e( 'Filter by category', 'smitra-notice-board-manager' ); ?></td></tr>
						<tr><td><code>[noticeboard tag="slug"]</code></td><td><?php esc_html_e( 'Filter by tag', 'smitra-notice-board-manager' ); ?></td></tr>
						<tr><td><code>[noticeboard show_search="no"]</code></td><td><?php esc_html_e( 'Hide search bar', 'smitra-notice-board-manager' ); ?></td></tr>
						<tr><td><code>[notice_submit_form]</code></td><td><?php esc_html_e( 'Frontend notice submission form (visible to allowed roles only)', 'smitra-notice-board-manager' ); ?></td></tr>
					</tbody>
				</table>
				<br>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
