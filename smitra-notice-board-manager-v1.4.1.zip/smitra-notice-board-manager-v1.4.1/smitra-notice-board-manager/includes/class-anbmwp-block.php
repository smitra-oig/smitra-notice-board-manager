<?php
/**
 * Gutenberg Block
 *
 * Registers the Notice Board Gutenberg block.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Block
 *
 * @since 1.0.0
 */
class ANBMWP_Block {

	/**
	 * Initialize block.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Register Gutenberg block.
	 *
	 * @since 1.0.0
	 */
	public static function register() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		wp_register_script(
			'anbmwp-block-editor',
			ANBMWP_PLUGIN_URL . 'blocks/block.js',
			array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n' ),
			ANBMWP_VERSION,
			true
		);

		register_block_type(
			'smitra-notice-board-manager/listing',
			array(
				'editor_script'   => 'anbmwp-block-editor',
				'render_callback' => array( __CLASS__, 'render' ),
				'attributes'      => array(
					'layout'      => array( 'type' => 'string', 'default' => 'list' ),
					'posts'       => array( 'type' => 'number', 'default' => 10 ),
					'show_search' => array( 'type' => 'string', 'default' => 'yes' ),
					'category'    => array( 'type' => 'string', 'default' => '' ),
				),
			)
		);
	}

	/**
	 * Server-side render callback.
	 *
	 * @since  1.0.0
	 * @param  array $atts Block attributes.
	 * @return string HTML output.
	 */
	public static function render( $atts ) {
		return ANBMWP_Shortcode::render( $atts );
	}
}
