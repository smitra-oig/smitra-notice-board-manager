<?php
/**
 * Post Type Registration
 *
 * Registers the Notice custom post type and its taxonomies.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Post_Type
 *
 * Handles registration of the Notice CPT, categories and tags.
 *
 * @since 1.0.0
 */
class ANBMWP_Post_Type {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'post_updated_messages', array( __CLASS__, 'messages' ) );
		add_action( 'admin_init', array( __CLASS__, 'restrict_access' ) );
	}

	/**
	 * Register CPT and taxonomies.
	 *
	 * @since 1.0.0
	 */
	public static function register() {
		$options      = get_option( 'anbmwp_settings', array() );
		$notice_slug  = ! empty( $options['notice_slug'] )   ? sanitize_title( $options['notice_slug'] )   : 'notices';
		$cat_slug     = ! empty( $options['category_slug'] ) ? sanitize_title( $options['category_slug'] ) : 'notice-category';
		$tag_slug     = ! empty( $options['tag_slug'] )      ? sanitize_title( $options['tag_slug'] )      : 'notice-tag';

		$labels = array(
			'name'               => _x( 'Notices', 'post type general name', 'smitra-notice-board-manager' ),
			'singular_name'      => _x( 'Notice', 'post type singular name', 'smitra-notice-board-manager' ),
			'add_new'            => __( 'Add Notice', 'smitra-notice-board-manager' ),
			'add_new_item'       => __( 'Add New Notice', 'smitra-notice-board-manager' ),
			'edit_item'          => __( 'Edit Notice', 'smitra-notice-board-manager' ),
			'new_item'           => __( 'New Notice', 'smitra-notice-board-manager' ),
			'view_item'          => __( 'View Notice', 'smitra-notice-board-manager' ),
			'search_items'       => __( 'Search Notices', 'smitra-notice-board-manager' ),
			'not_found'          => __( 'No notices found', 'smitra-notice-board-manager' ),
			'not_found_in_trash' => __( 'No notices found in trash', 'smitra-notice-board-manager' ),
			'menu_name'          => __( 'Notice Board', 'smitra-notice-board-manager' ),
		);

		$args = array(
			'labels'          => $labels,
			'public'          => true,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'show_in_rest'    => true,
			'menu_icon'       => 'dashicons-megaphone',
			'supports'        => array( 'title', 'editor', 'thumbnail' ),
			'has_archive'     => true,
			'rewrite'         => array( 'slug' => $notice_slug ),
			'capability_type' => array( 'anbmwp_notice', 'anbmwp_notices' ),
			'map_meta_cap'    => true,
			'capabilities'    => array(
				// Primitive capabilities
				'edit_posts'             => 'edit_anbmwp_notices',
				'edit_others_posts'      => 'edit_others_anbmwp_notices',
				'publish_posts'          => 'publish_anbmwp_notices',
				'read_private_posts'     => 'read_private_anbmwp_notices',
				'delete_posts'           => 'delete_anbmwp_notices',
				'delete_private_posts'   => 'delete_private_anbmwp_notices',
				'delete_published_posts' => 'delete_published_anbmwp_notices',
				'delete_others_posts'    => 'delete_others_anbmwp_notices',
				'edit_private_posts'     => 'edit_private_anbmwp_notices',
				'edit_published_posts'   => 'edit_published_anbmwp_notices',
				// Meta capabilities
				'read'                   => 'read',
				'create_posts'           => 'create_anbmwp_notices',
			),
		);

		register_post_type( 'anbmwp_notice', $args );

		// Grant capabilities to Administrator and Editor on activation
		self::grant_caps_to_roles();

		// Notice Categories
		register_taxonomy( 'anbmwp_category', 'anbmwp_notice', array(
			'labels'            => array(
				'name'          => __( 'Notice Categories', 'smitra-notice-board-manager' ),
				'singular_name' => __( 'Category', 'smitra-notice-board-manager' ),
				'add_new_item'  => __( 'Add New Category', 'smitra-notice-board-manager' ),
				'edit_item'     => __( 'Edit Category', 'smitra-notice-board-manager' ),
			),
			'hierarchical'      => true,
			'show_ui'           => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => $cat_slug ),
		) );

		// Notice Tags
		register_taxonomy( 'anbmwp_tag', 'anbmwp_notice', array(
			'labels'            => array(
				'name'          => __( 'Notice Tags', 'smitra-notice-board-manager' ),
				'singular_name' => __( 'Tag', 'smitra-notice-board-manager' ),
				'add_new_item'  => __( 'Add New Tag', 'smitra-notice-board-manager' ),
				'edit_item'     => __( 'Edit Tag', 'smitra-notice-board-manager' ),
			),
			'hierarchical'      => false,
			'show_ui'           => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => $tag_slug ),
		) );
	}

	/**
	 * Grant Notice Board capabilities to Administrator and Editor roles.
	 * Called on register and activation so roles always have access.
	 *
	 * @since 1.3.0
	 */
	public static function grant_caps_to_roles() {
		$caps = array(
			'edit_anbmwp_notices',
			'edit_others_anbmwp_notices',
			'publish_anbmwp_notices',
			'read_private_anbmwp_notices',
			'delete_anbmwp_notices',
			'delete_private_anbmwp_notices',
			'delete_published_anbmwp_notices',
			'delete_others_anbmwp_notices',
			'edit_private_anbmwp_notices',
			'edit_published_anbmwp_notices',
			'create_anbmwp_notices',
		);

		$roles = array( 'administrator', 'editor' );

		foreach ( $roles as $role_name ) {
			$role = get_role( $role_name );
			if ( $role ) {
				foreach ( $caps as $cap ) {
					$role->add_cap( $cap );
				}
			}
		}
	}

	/**
	 * Restrict WP admin menu access — hide Notice Board for roles
	 * that do not have the edit_anbmwp_notices capability.
	 *
	 * @since 1.0.0
	 */
	public static function restrict_access() {
		if ( ! current_user_can( 'edit_anbmwp_notices' ) ) {
			remove_menu_page( 'edit.php?post_type=anbmwp_notice' );
		}
	}

	/**
	 * Custom post updated messages.
	 *
	 * @since  1.0.0
	 * @param  array $messages Existing messages.
	 * @return array
	 */
	public static function messages( $messages ) {
		$messages['anbmwp_notice'] = array(
			0  => '',
			1  => __( 'Notice updated.', 'smitra-notice-board-manager' ),
			2  => __( 'Custom field updated.', 'smitra-notice-board-manager' ),
			3  => __( 'Custom field deleted.', 'smitra-notice-board-manager' ),
			4  => __( 'Notice updated.', 'smitra-notice-board-manager' ),
			6  => __( 'Notice published.', 'smitra-notice-board-manager' ),
			7  => __( 'Notice saved.', 'smitra-notice-board-manager' ),
			8  => __( 'Notice submitted.', 'smitra-notice-board-manager' ),
			10 => __( 'Notice draft updated.', 'smitra-notice-board-manager' ),
		);
		return $messages;
	}
}
