<?php
/**
 * Notice Expiry Handler
 *
 * Automatically hides and unpublishes notices past their expiry date.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Expiry
 *
 * @since 1.0.0
 */
class ANBMWP_Expiry {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'wp',                   array( __CLASS__, 'filter_expired_notices' ) );
		add_action( 'anbmwp_check_expiry',  array( __CLASS__, 'run_expiry_check' ) );

		// Schedule daily expiry check on activation (called from main file)
		if ( ! wp_next_scheduled( 'anbmwp_check_expiry' ) ) {
			wp_schedule_event( time(), 'daily', 'anbmwp_check_expiry' );
		}
	}

	/**
	 * Exclude expired notices from frontend queries.
	 *
	 * @since 1.0.0
	 */
	public static function filter_expired_notices() {
		add_filter( 'pre_get_posts', array( __CLASS__, 'exclude_expired' ) );
	}

	/**
	 * Modify query to exclude expired notices.
	 *
	 * @since  1.0.0
	 * @param  WP_Query $query Current query object.
	 * @return WP_Query
	 */
	public static function exclude_expired( $query ) {
		if ( is_admin() ) {
			return $query;
		}
		if ( ! $query->is_main_query() ) {
			return $query;
		}
		if ( empty( $query->query_vars['post_type'] ) || 'anbmwp_notice' !== $query->query_vars['post_type'] ) {
			return $query;
		}

		$today      = gmdate( 'Y-m-d' );
		$meta_query = $query->get( 'meta_query' ) ?: array();

		$meta_query[] = array(
			'relation' => 'OR',
			array(
				'key'     => '_anbmwp_expiry_date',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => '_anbmwp_expiry_date',
				'value'   => '',
				'compare' => '=',
			),
			array(
				'key'     => '_anbmwp_expiry_date',
				'value'   => $today,
				'compare' => '>=',
				'type'    => 'DATE',
			),
		);

		$query->set( 'meta_query', $meta_query );
		return $query;
	}

	/**
	 * Daily cron: unpublish expired notices.
	 *
	 * @since 1.0.0
	 */
	public static function run_expiry_check() {
		$today   = gmdate( 'Y-m-d' );
		$expired = get_posts( array(
			'post_type'      => 'anbmwp_notice',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'meta_query'     => array(
				array(
					'key'     => '_anbmwp_expiry_date',
					'value'   => $today,
					'compare' => '<',
					'type'    => 'DATE',
				),
			),
		) );

		foreach ( $expired as $notice ) {
			wp_update_post( array(
				'ID'          => $notice->ID,
				'post_status' => 'draft',
			) );
		}
	}
}
