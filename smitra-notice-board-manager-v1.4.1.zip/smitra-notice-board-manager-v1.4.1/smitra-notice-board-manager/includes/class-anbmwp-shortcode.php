<?php
/**
 * Shortcode Handler
 *
 * Registers and renders the [noticeboard] shortcode.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Shortcode
 *
 * @since 1.0.0
 */
class ANBMWP_Shortcode {

	/**
	 * Initialize shortcode.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_shortcode( 'noticeboard', array( __CLASS__, 'render' ) );
	}

	/**
	 * Render noticeboard shortcode.
	 *
	 * Usage:
	 *   [noticeboard]
	 *   [noticeboard layout="grid"]
	 *   [noticeboard posts="5" category="slug" show_search="no"]
	 *
	 * @since  1.0.0
	 * @param  array $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	public static function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'layout'      => 'list',
				'category'    => '',
				'tag'         => '',
				'posts'       => 10,
				'show_search' => 'yes',
			),
			$atts,
			'noticeboard'
		);

		$today = gmdate( 'Y-m-d' );

		$args = array(
			'post_type'      => 'anbmwp_notice',
			'post_status'    => 'publish',
			'posts_per_page' => intval( $atts['posts'] ),
			'meta_query'     => array(
				'relation' => 'OR',
				array( 'key' => '_anbmwp_expiry_date', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_anbmwp_expiry_date', 'value' => '', 'compare' => '=' ),
				array( 'key' => '_anbmwp_expiry_date', 'value' => $today, 'compare' => '>=', 'type' => 'DATE' ),
			),
			'meta_key'       => '_anbmwp_pinned',
			'orderby'        => array( 'meta_value' => 'DESC', 'date' => 'DESC' ),
		);

		if ( ! empty( $atts['category'] ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'anbmwp_category',
				'field'    => 'slug',
				'terms'    => explode( ',', sanitize_text_field( $atts['category'] ) ),
			);
		}
		if ( ! empty( $atts['tag'] ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'anbmwp_tag',
				'field'    => 'slug',
				'terms'    => explode( ',', sanitize_text_field( $atts['tag'] ) ),
			);
		}

		// Handle search filter
		if ( ! empty( $_GET['anbmwp_search'] ) ) {
			$args['s'] = sanitize_text_field( wp_unslash( $_GET['anbmwp_search'] ) );
		}
		if ( ! empty( $_GET['anbmwp_category'] ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'anbmwp_category',
				'field'    => 'slug',
				'terms'    => sanitize_text_field( wp_unslash( $_GET['anbmwp_category'] ) ),
			);
		}

		$notices = new WP_Query( $args );
		$layout  = in_array( $atts['layout'], array( 'list', 'grid' ), true ) ? $atts['layout'] : 'list';

		ob_start();

		if ( 'yes' === $atts['show_search'] ) {
			self::render_search_bar();
		}

		echo '<div class="anbmwp-wrapper anbmwp-layout-' . esc_attr( $layout ) . '">';

		if ( $notices->have_posts() ) {
			while ( $notices->have_posts() ) {
				$notices->the_post();
				$template = ANBMWP_PLUGIN_DIR . 'templates/' . $layout . '/notice-item.php';
				if ( file_exists( $template ) ) {
					include $template;
				}
			}
			wp_reset_postdata();
		} else {
			$options         = get_option( 'anbmwp_settings', array() );
			$no_notices_text = ! empty( $options['no_notices_text'] ) ? $options['no_notices_text'] : __( 'No notices found.', 'smitra-notice-board-manager' );
			echo '<p class="anbmwp-no-notices">' . esc_html( $no_notices_text ) . '</p>';
		}

		echo '</div>';

		return ob_get_clean();
	}

	/**
	 * Render search and filter bar.
	 *
	 * @since 1.0.0
	 */
	private static function render_search_bar() {
		$categories       = get_terms( array( 'taxonomy' => 'anbmwp_category', 'hide_empty' => true ) );
		$current_search   = isset( $_GET['anbmwp_search'] )   ? sanitize_text_field( wp_unslash( $_GET['anbmwp_search'] ) )   : '';
		$current_category = isset( $_GET['anbmwp_category'] ) ? sanitize_text_field( wp_unslash( $_GET['anbmwp_category'] ) ) : '';
		?>
		<div class="anbmwp-search-bar">
			<form method="GET" action="" class="anbmwp-search-form">
				<input type="text" name="anbmwp_search"
					value="<?php echo esc_attr( $current_search ); ?>"
					placeholder="<?php esc_attr_e( 'Search notices...', 'smitra-notice-board-manager' ); ?>"
					class="anbmwp-search-input" />
				<?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
					<select name="anbmwp_category" class="anbmwp-category-filter">
						<option value=""><?php esc_html_e( 'All Categories', 'smitra-notice-board-manager' ); ?></option>
						<?php foreach ( $categories as $cat ) : ?>
							<option value="<?php echo esc_attr( $cat->slug ); ?>" <?php selected( $current_category, $cat->slug ); ?>>
								<?php echo esc_html( $cat->name ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				<?php endif; ?>
				<button type="submit" class="anbmwp-search-btn"><?php esc_html_e( 'Search', 'smitra-notice-board-manager' ); ?></button>
				<?php if ( $current_search || $current_category ) : ?>
					<a href="<?php echo esc_url( strtok( isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/', '?' ) ); ?>" class="anbmwp-clear-btn">
						<?php esc_html_e( 'Clear', 'smitra-notice-board-manager' ); ?>
					</a>
				<?php endif; ?>
			</form>
		</div>
		<?php
	}
}
