<?php
/**
 * Elementor Widget
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

/**
 * Class ANBMWP_Elementor_Widget
 *
 * @since 1.0.0
 */
class ANBMWP_Elementor_Widget extends Widget_Base {

	public function get_name()        { return 'anbmwp_notice_board'; }
	public function get_title()       { return __( 'Notice Board', 'smitra-notice-board-manager' ); }
	public function get_icon()        { return 'eicon-bullet-list'; }
	public function get_categories()  { return array( 'anbmwp', 'general' ); }
	public function get_keywords()    { return array( 'notice', 'board', 'announcement', 'alert' ); }

	protected function register_controls() {

		$this->start_controls_section( 'section_content', array(
			'label' => __( 'Notice Board Settings', 'smitra-notice-board-manager' ),
			'tab'   => Controls_Manager::TAB_CONTENT,
		) );

		$this->add_control( 'layout', array(
			'label'   => __( 'Layout', 'smitra-notice-board-manager' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'list',
			'options' => array(
				'list' => __( 'List', 'smitra-notice-board-manager' ),
				'grid' => __( 'Grid', 'smitra-notice-board-manager' ),
			),
		) );

		$this->add_control( 'posts', array(
			'label'   => __( 'Number of Notices', 'smitra-notice-board-manager' ),
			'type'    => Controls_Manager::NUMBER,
			'default' => 10,
			'min'     => 1,
			'max'     => 50,
		) );

		$this->add_control( 'show_search', array(
			'label'     => __( 'Show Search Bar', 'smitra-notice-board-manager' ),
			'type'      => Controls_Manager::SWITCHER,
			'default'   => 'yes',
			'label_on'  => __( 'Show', 'smitra-notice-board-manager' ),
			'label_off' => __( 'Hide', 'smitra-notice-board-manager' ),
		) );

		$this->add_control( 'category', array(
			'label'       => __( 'Filter by Category Slug', 'smitra-notice-board-manager' ),
			'type'        => Controls_Manager::TEXT,
			'placeholder' => __( 'Leave empty for all', 'smitra-notice-board-manager' ),
		) );

		$this->end_controls_section();

		$this->start_controls_section( 'section_style', array(
			'label' => __( 'Style', 'smitra-notice-board-manager' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		) );

		$this->add_control( 'accent_color', array(
			'label'     => __( 'Accent Color', 'smitra-notice-board-manager' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#0073aa',
			'selectors' => array(
				'{{WRAPPER}} .anbmwp-btn-read'   => 'background-color: {{VALUE}};',
				'{{WRAPPER}} .anbmwp-search-btn' => 'background-color: {{VALUE}};',
			),
		) );

		$this->add_control( 'border_radius', array(
			'label'     => __( 'Border Radius', 'smitra-notice-board-manager' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
			'default'   => array( 'size' => 8 ),
			'selectors' => array(
				'{{WRAPPER}} .anbmwp-item' => 'border-radius: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		echo ANBMWP_Shortcode::render( array(
			'layout'      => $settings['layout'],
			'posts'       => $settings['posts'],
			'show_search' => 'yes' === $settings['show_search'] ? 'yes' : 'no',
			'category'    => isset( $settings['category'] ) ? $settings['category'] : '',
		) );
	}
}
