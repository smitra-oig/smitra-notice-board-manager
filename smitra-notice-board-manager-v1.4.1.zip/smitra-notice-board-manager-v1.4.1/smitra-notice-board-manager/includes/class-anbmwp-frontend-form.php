<?php
/**
 * Frontend Notice Submission Form
 *
 * Provides [notice_submit_form] shortcode for role-restricted frontend notice posting.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Frontend_Form
 *
 * @since 1.0.0
 */
class ANBMWP_Frontend_Form {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_shortcode( 'notice_submit_form', array( __CLASS__, 'render' ) );
		add_action( 'wp_ajax_anbmwp_submit_notice',        array( __CLASS__, 'handle_submission' ) );
		add_action( 'wp_ajax_nopriv_anbmwp_submit_notice', array( __CLASS__, 'handle_submission_nopriv' ) );
		add_action( 'wp_enqueue_scripts',                  array( __CLASS__, 'enqueue' ) );
	}

	/**
	 * Check if current user has an allowed role.
	 *
	 * @since  1.0.0
	 * @return bool
	 */
	public static function user_can_submit() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$options       = get_option( 'anbmwp_settings', array() );
		$allowed_roles = ! empty( $options['form_allowed_roles'] ) ? (array) $options['form_allowed_roles'] : array( 'administrator', 'editor' );
		$user          = wp_get_current_user();
		return (bool) array_intersect( (array) $user->roles, $allowed_roles );
	}

	/**
	 * Enqueue frontend form scripts.
	 *
	 * @since 1.0.0
	 */
	public static function enqueue() {
		wp_enqueue_script(
			'anbmwp-frontend-form',
			ANBMWP_PLUGIN_URL . 'assets/js/frontend-form.js',
			array( 'jquery' ),
			ANBMWP_VERSION,
			true
		);
		wp_localize_script( 'anbmwp-frontend-form', 'anbmwp_form', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'anbmwp_submit_notice' ),
		) );
	}

	/**
	 * Render the frontend submission form shortcode.
	 *
	 * @since  1.0.0
	 * @param  array $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	public static function render( $atts ) {
		$options    = get_option( 'anbmwp_settings', array() );
		$login_page = ! empty( $options['login_page_url'] ) ? $options['login_page_url'] : wp_login_url( get_permalink() );

		if ( ! is_user_logged_in() ) {
			return '<div class="anbmwp-form-login-notice">
				<p>🔒 ' . esc_html__( 'You must be logged in to submit a notice.', 'smitra-notice-board-manager' ) . '</p>
				<a href="' . esc_url( $login_page ) . '" class="anbmwp-btn anbmwp-btn-login">' . esc_html__( 'Log In', 'smitra-notice-board-manager' ) . '</a>
			</div>';
		}

		if ( ! self::user_can_submit() ) {
			return '<div class="anbmwp-form-no-access">
				<p>🚫 ' . esc_html__( 'You do not have permission to submit notices.', 'smitra-notice-board-manager' ) . '</p>
			</div>';
		}

		$categories = get_terms( array( 'taxonomy' => 'anbmwp_category', 'hide_empty' => false ) );

		ob_start();
		?>
		<div class="anbmwp-frontend-form-wrap" id="anbmwp-frontend-form-wrap">
			<div id="anbmwp-form-success" class="anbmwp-form-success" style="display:none;"></div>
			<div id="anbmwp-form-error"   class="anbmwp-form-error"   style="display:none;"></div>

			<form id="anbmwp-submit-form" class="anbmwp-submit-form" enctype="multipart/form-data">
				<?php wp_nonce_field( 'anbmwp_submit_notice', 'anbmwp_form_nonce' ); ?>

				<div class="anbmwp-form-group">
					<label for="anbmwp_f_title"><?php esc_html_e( 'Notice Title', 'smitra-notice-board-manager' ); ?> <span class="anbmwp-required-star">*</span></label>
					<input type="text" id="anbmwp_f_title" name="anbmwp_f_title" required
						placeholder="<?php esc_attr_e( 'Enter notice title...', 'smitra-notice-board-manager' ); ?>" />
				</div>

				<div class="anbmwp-form-group">
					<label for="anbmwp_f_summary"><?php esc_html_e( 'Short Summary', 'smitra-notice-board-manager' ); ?></label>
					<textarea id="anbmwp_f_summary" name="anbmwp_f_summary" rows="3"
						placeholder="<?php esc_attr_e( 'Brief description shown in notice listings...', 'smitra-notice-board-manager' ); ?>"></textarea>
				</div>

				<div class="anbmwp-form-group">
					<label for="anbmwp_f_content"><?php esc_html_e( 'Full Notice Content', 'smitra-notice-board-manager' ); ?> <span class="anbmwp-required-star">*</span></label>
					<textarea id="anbmwp_f_content" name="anbmwp_f_content" rows="8" required
						placeholder="<?php esc_attr_e( 'Write the full notice content here...', 'smitra-notice-board-manager' ); ?>"></textarea>
				</div>

				<?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
				<div class="anbmwp-form-group">
					<label for="anbmwp_f_category"><?php esc_html_e( 'Category', 'smitra-notice-board-manager' ); ?></label>
					<select id="anbmwp_f_category" name="anbmwp_f_category">
						<option value=""><?php esc_html_e( '— Select Category —', 'smitra-notice-board-manager' ); ?></option>
						<?php foreach ( $categories as $cat ) : ?>
							<option value="<?php echo esc_attr( $cat->term_id ); ?>"><?php echo esc_html( $cat->name ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<?php endif; ?>

				<div class="anbmwp-form-group">
					<label for="anbmwp_f_expiry"><?php esc_html_e( 'Expiry Date', 'smitra-notice-board-manager' ); ?></label>
					<input type="date" id="anbmwp_f_expiry" name="anbmwp_f_expiry" min="<?php echo esc_attr( gmdate( 'Y-m-d' ) ); ?>" />
					<small><?php esc_html_e( 'Leave empty for no expiry.', 'smitra-notice-board-manager' ); ?></small>
				</div>

				<div class="anbmwp-form-group">
					<label for="anbmwp_f_attachment"><?php esc_html_e( 'Attachment (PDF / Document)', 'smitra-notice-board-manager' ); ?></label>
					<input type="file" id="anbmwp_f_attachment" name="anbmwp_f_attachment" accept=".pdf,.doc,.docx,.txt,.odt" />
					<small><?php esc_html_e( 'Accepted: PDF, DOC, DOCX, TXT, ODT', 'smitra-notice-board-manager' ); ?></small>
				</div>

				<div class="anbmwp-form-group">
					<label for="anbmwp_f_external_link"><?php esc_html_e( 'External Link', 'smitra-notice-board-manager' ); ?></label>
					<input type="text" id="anbmwp_f_external_link" name="anbmwp_f_external_link" placeholder="https://" />
					<small><?php esc_html_e( 'Optional. Opens in a new tab on the notice page.', 'smitra-notice-board-manager' ); ?></small>
				</div>

				<div class="anbmwp-form-group">
					<label for="anbmwp_f_link_btn_text"><?php esc_html_e( 'External Link Button Text', 'smitra-notice-board-manager' ); ?></label>
					<input type="text" id="anbmwp_f_link_btn_text" name="anbmwp_f_link_btn_text" placeholder="<?php esc_attr_e( 'Learn More', 'smitra-notice-board-manager' ); ?>" />
					<small><?php esc_html_e( 'Leave empty to use default: "Learn More"', 'smitra-notice-board-manager' ); ?></small>
				</div>

				<div class="anbmwp-form-flags">
					<label class="anbmwp-form-flag-label">
						<input type="checkbox" name="anbmwp_f_pinned" value="1" />
						<span class="anbmwp-badge anbmwp-badge-pin">📌 <?php esc_html_e( 'Pin this notice', 'smitra-notice-board-manager' ); ?></span>
					</label>
					<label class="anbmwp-form-flag-label">
						<input type="checkbox" name="anbmwp_f_urgent" value="1" />
						<span class="anbmwp-badge anbmwp-badge-urgent">⚠ <?php esc_html_e( 'Mark as urgent', 'smitra-notice-board-manager' ); ?></span>
					</label>
					<label class="anbmwp-form-flag-label">
						<input type="checkbox" name="anbmwp_f_login_required" value="1" />
						<span class="anbmwp-badge anbmwp-badge-lock">🔒 <?php esc_html_e( 'Members Only', 'smitra-notice-board-manager' ); ?></span>
					</label>
				</div>

				<div class="anbmwp-form-submit">
					<button type="submit" id="anbmwp-submit-btn" class="anbmwp-btn anbmwp-btn-submit">
						<?php esc_html_e( 'Submit Notice', 'smitra-notice-board-manager' ); ?>
					</button>
					<span id="anbmwp-form-spinner" class="anbmwp-spinner" style="display:none;">
						⏳ <?php esc_html_e( 'Submitting...', 'smitra-notice-board-manager' ); ?>
					</span>
				</div>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Handle AJAX form submission for logged-in users.
	 *
	 * @since 1.0.0
	 */
	public static function handle_submission() {
		if ( ! isset( $_POST['anbmwp_form_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['anbmwp_form_nonce'] ) ), 'anbmwp_submit_notice' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed. Please refresh and try again.', 'smitra-notice-board-manager' ) ) );
		}

		if ( ! self::user_can_submit() ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to submit notices.', 'smitra-notice-board-manager' ) ) );
		}

		$title   = isset( $_POST['anbmwp_f_title'] )   ? sanitize_text_field( wp_unslash( $_POST['anbmwp_f_title'] ) )   : '';
		$content = isset( $_POST['anbmwp_f_content'] ) ? wp_kses_post( wp_unslash( $_POST['anbmwp_f_content'] ) )         : '';

		if ( empty( $title ) ) {
			wp_send_json_error( array( 'message' => __( 'Notice title is required.', 'smitra-notice-board-manager' ) ) );
		}
		if ( empty( $content ) ) {
			wp_send_json_error( array( 'message' => __( 'Notice content is required.', 'smitra-notice-board-manager' ) ) );
		}

		$options     = get_option( 'anbmwp_settings', array() );
		$post_status = ( ! empty( $options['form_submission'] ) && 'publish' === $options['form_submission'] ) ? 'publish' : 'draft';
		$success_msg = ! empty( $options['form_success_message'] ) ? $options['form_success_message'] : __( 'Your notice has been submitted successfully.', 'smitra-notice-board-manager' );

		$post_id = wp_insert_post( array(
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => $post_status,
			'post_type'    => 'anbmwp_notice',
			'post_author'  => get_current_user_id(),
		) );

		if ( is_wp_error( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Failed to submit notice. Please try again.', 'smitra-notice-board-manager' ) ) );
		}

		$summary        = isset( $_POST['anbmwp_f_summary'] )       ? sanitize_textarea_field( wp_unslash( $_POST['anbmwp_f_summary'] ) )  : '';
		$expiry         = isset( $_POST['anbmwp_f_expiry'] )        ? sanitize_text_field( wp_unslash( $_POST['anbmwp_f_expiry'] ) )       : '';
		$external_link  = isset( $_POST['anbmwp_f_external_link'] ) ? esc_url_raw( wp_unslash( $_POST['anbmwp_f_external_link'] ) )        : '';
		$link_btn_text  = isset( $_POST['anbmwp_f_link_btn_text'] ) ? sanitize_text_field( wp_unslash( $_POST['anbmwp_f_link_btn_text'] ) ) : '';
		$pinned         = ! empty( $_POST['anbmwp_f_pinned'] )         ? '1' : '0';
		$urgent         = ! empty( $_POST['anbmwp_f_urgent'] )         ? '1' : '0';
		$login_required = ! empty( $_POST['anbmwp_f_login_required'] ) ? '1' : '0';

		if ( $summary )       update_post_meta( $post_id, '_anbmwp_short_summary',  $summary );
		if ( $expiry )        update_post_meta( $post_id, '_anbmwp_expiry_date',    $expiry );
		if ( $external_link ) update_post_meta( $post_id, '_anbmwp_external_link',  $external_link );
		if ( $link_btn_text ) update_post_meta( $post_id, '_anbmwp_link_btn_text',  $link_btn_text );
		update_post_meta( $post_id, '_anbmwp_pinned',         $pinned );
		update_post_meta( $post_id, '_anbmwp_urgent',         $urgent );
		update_post_meta( $post_id, '_anbmwp_login_required', $login_required );

		$category_id = isset( $_POST['anbmwp_f_category'] ) ? intval( $_POST['anbmwp_f_category'] ) : 0;
		if ( $category_id ) {
			wp_set_post_terms( $post_id, array( $category_id ), 'anbmwp_category' );
		}

		if ( ! empty( $_FILES['anbmwp_f_attachment']['name'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';

			$allowed_types = array(
				'application/pdf',
				'application/msword',
				'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'text/plain',
				'application/vnd.oasis.opendocument.text',
			);

			$file_type = isset( $_FILES['anbmwp_f_attachment']['type'] ) ? sanitize_text_field( wp_unslash( $_FILES['anbmwp_f_attachment']['type'] ) ) : '';

			if ( ! in_array( $file_type, $allowed_types, true ) ) {
				wp_send_json_error( array( 'message' => __( 'Invalid file type. Allowed: PDF, DOC, DOCX, TXT, ODT.', 'smitra-notice-board-manager' ) ) );
			}

			$attachment_id = media_handle_upload( 'anbmwp_f_attachment', $post_id );
			if ( ! is_wp_error( $attachment_id ) ) {
				update_post_meta( $post_id, '_anbmwp_attachment', wp_get_attachment_url( $attachment_id ) );
			}
		}

		$message = 'publish' === $post_status
			? $success_msg
			: __( 'Your notice has been submitted and is pending admin approval.', 'smitra-notice-board-manager' );

		wp_send_json_success( array( 'message' => $message ) );
	}

	/**
	 * Reject non-logged-in AJAX attempts.
	 *
	 * @since 1.0.0
	 */
	public static function handle_submission_nopriv() {
		wp_send_json_error( array( 'message' => __( 'You must be logged in to submit a notice.', 'smitra-notice-board-manager' ) ) );
	}
}
