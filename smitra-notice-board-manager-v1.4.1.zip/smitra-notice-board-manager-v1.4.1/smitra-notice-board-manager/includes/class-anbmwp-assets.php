<?php
/**
 * Assets Handler
 *
 * Enqueues frontend and admin stylesheets and scripts.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Assets
 *
 * @since 1.0.0
 */
class ANBMWP_Assets {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts',    array( __CLASS__, 'frontend' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin' ) );
		add_filter( 'the_content',           array( __CLASS__, 'inject_single_template' ), 99 );
	}

	/**
	 * Enqueue frontend styles.
	 *
	 * @since 1.0.0
	 */
	public static function frontend() {
		wp_enqueue_style(
			'anbmwp-frontend',
			ANBMWP_PLUGIN_URL . 'assets/css/notice-board.css',
			array(),
			ANBMWP_VERSION
		);
	}

	/**
	 * Enqueue admin styles.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 */
	public static function admin( $hook ) {
		global $post_type;
		if ( 'anbmwp_notice' !== $post_type ) {
			return;
		}
		wp_enqueue_style(
			'anbmwp-admin',
			ANBMWP_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			ANBMWP_VERSION
		);
	}

	/**
	 * Inject single notice template via the_content filter.
	 * Only fires if theme does not have its own single-anbmwp_notice.php.
	 *
	 * @since  1.0.0
	 * @param  string $content Post content.
	 * @return string Modified content.
	 */
	public static function inject_single_template( $content ) {
		global $post;

		if ( ! $post || 'anbmwp_notice' !== $post->post_type ) {
			return $content;
		}
		if ( ! is_singular( 'anbmwp_notice' ) ) {
			return $content;
		}
		if ( ! in_the_loop() ) {
			return $content;
		}

		// Let theme override take precedence
		$theme_template = locate_template( 'single-anbmwp_notice.php' );
		if ( $theme_template ) {
			return $content;
		}

		remove_filter( 'the_content', array( __CLASS__, 'inject_single_template' ), 99 );

		ob_start();
		$template = ANBMWP_PLUGIN_DIR . 'templates/single/notice-single.php';
		if ( file_exists( $template ) ) {
			include $template;
		}
		return ob_get_clean();
	}
}
