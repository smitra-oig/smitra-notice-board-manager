<?php
/**
 * Elementor Integration
 *
 * Registers the Notice Board Elementor widget category and widget.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ANBMWP_Elementor
 *
 * @since 1.0.0
 */
class ANBMWP_Elementor {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		// Only load if Elementor is active
		add_action( 'plugins_loaded', array( __CLASS__, 'check_elementor' ) );
	}

	/**
	 * Check if Elementor is active before registering.
	 *
	 * @since 1.0.0
	 */
	public static function check_elementor() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}
		add_action( 'elementor/widgets/register',              array( __CLASS__, 'register_widget' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'add_category' ) );
	}

	/**
	 * Add custom Elementor category.
	 *
	 * @since 1.0.0
	 * @param object $manager Elements manager instance.
	 */
	public static function add_category( $manager ) {
		$manager->add_category(
			'anbmwp',
			array(
				'title' => __( 'Notice Board', 'smitra-notice-board-manager' ),
				'icon'  => 'fa fa-bullhorn',
			)
		);
	}

	/**
	 * Register Elementor widget.
	 *
	 * @since 1.0.0
	 * @param object $manager Widgets manager instance.
	 */
	public static function register_widget( $manager ) {
		require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-elementor-widget.php';
		$manager->register( new ANBMWP_Elementor_Widget() );
	}
}
