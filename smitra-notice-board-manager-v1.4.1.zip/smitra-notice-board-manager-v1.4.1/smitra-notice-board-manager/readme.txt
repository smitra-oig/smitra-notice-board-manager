=== Smitra Notice Board Manager ===
Contributors: subhajit9836
Tags: notice board, announcements, notices, community, residential
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.4.1
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A professional notice board management system for WordPress. Perfect for residential communities, schools, corporates, and any organisation that needs a structured notice board.

== Description ==

**Smitra Notice Board Manager** is a powerful, lightweight, and fully featured notice board plugin for WordPress. It provides everything you need to create and manage a professional notice board on your website — with zero coding required.

Whether you manage a residential community, a school, a corporate intranet, or any organisation that needs structured announcements, this plugin gives you a clean, role-controlled notice management system right inside WordPress.

= Key Features =

**Notice Management**
* Create and manage notices with a clean, structured admin form
* Short Summary field for listing previews
* Full Notice content with the standard WordPress editor
* PDF / Document attachment support
* Expiry Date — notices automatically disappear after a set date
* Daily cron job silently unpublishes expired notices in the background

**Notice Flags**
* 📌 **Pin notices** — pinned notices always appear at the top of listings
* ⚠ **Urgent notices** — mark important notices with a visible urgent label
* 🔒 **Members Only** — restrict individual notices to logged-in users only

**Content Restriction**
* Per-notice login restriction toggle
* Guests see the notice title but all content is locked
* Customisable locked message and login redirect URL

**Frontend Submission Form**
* `[notice_submit_form]` shortcode — place a notice submission form on any page
* Role-based access control — choose which roles can submit notices
* Admin selects submission mode: Auto Publish or Save as Draft for approval
* Customisable success message
* File upload support for PDF and documents

**Display Options**
* List view layout
* Grid view layout
* Search and filter bar with category dropdown
* Shortcode with full attribute support
* Gutenberg block with sidebar controls
* Elementor widget with style controls

**Customisation**
* Customisable archive, category, and tag slugs
* Customisable back button text and URL
* Customisable "No Notices Found" text
* Customisable "View All" button text

**Developer Friendly**
* Clean OOP architecture — one class per concern
* All strings translation-ready with `.pot` file
* Standard WordPress hooks and filters throughout
* Theme template override support (`single-anbmwp_notice.php`)
* Proper uninstall cleanup — no leftover data

= Shortcodes =

`[noticeboard]` — Display all notices in default list view
`[noticeboard layout="grid"]` — Grid layout
`[noticeboard posts="5"]` — Limit to 5 notices
`[noticeboard category="slug"]` — Filter by category slug
`[noticeboard tag="slug"]` — Filter by tag slug
`[noticeboard show_search="no"]` — Hide the search bar
`[notice_submit_form]` — Frontend notice submission form

= Who Is This For? =

* Residential communities and apartment complexes
* Schools and educational institutions
* Corporate intranets and office portals
* Any organisation needing a structured notice board

= Privacy Policy =

This plugin does not collect, store, or transmit any personal data to external services. All data is stored locally in your WordPress database.

== Installation ==

1. Upload the `smitra-notice-board-manager` folder to the `/wp-content/plugins/` directory, or install directly via the WordPress Plugin Directory.
2. Activate the plugin from the **Plugins** menu in WordPress.
3. Go to **Notice Board → Settings** to configure the plugin.
4. Go to **Notice Board → Add Notice** to create your first notice.
5. Add `[noticeboard]` to any page or post to display notices.

== Frequently Asked Questions ==

= How do I display notices on a page? =

Add the shortcode `[noticeboard]` to any page, post, or widget. You can also use the Gutenberg block or Elementor widget.

= How do I restrict a notice to logged-in users only? =

Edit the notice and check the **🔒 MEMBERS ONLY** checkbox in the Notice Details meta box. Guests will see the title but content will be locked.

= Can I customise the login redirect URL for locked notices? =

Yes. Go to **Notice Board → Settings → Content Restriction Settings** and enter your custom login page URL.

= How do I change the notices URL slug? =

Go to **Notice Board → Settings → Slug Settings** and update the slug. After saving, go to **Settings → Permalinks** and click Save to flush rewrite rules.

= Can I let specific users submit notices from the frontend? =

Yes. Go to **Notice Board → Settings → Frontend Notice Form Settings**, select the allowed roles, place `[notice_submit_form]` on a page, and those users will see the form when logged in.

= Does this plugin work with Elementor? =

Yes. The plugin includes a dedicated Elementor widget in the **Notice Board** widget category. It is only loaded if Elementor is active.

= Does this plugin work with Gutenberg? =

Yes. A Gutenberg block is included. Search for "Notice Board" in the block inserter.

= What happens to notices after the expiry date? =

Notices past their expiry date are automatically moved to Draft status by a daily background process. They remain in your admin for reference.

= Can I override the single notice template? =

Yes. Create a file named `single-anbmwp_notice.php` in your active theme's root directory and the plugin will use it instead.

== Screenshots ==

1. Notice listing in List view with pinned and urgent badges
2. Notice listing in Grid view
3. Single notice page with attachment download
4. Admin notice editor with all meta fields
5. Plugin Settings page
6. Frontend notice submission form
7. Locked notice view for guests

== Changelog ==

= 1.4.1 =
* Changed: Plugin renamed to "Smitra Notice Board Manager" (new slug and text domain)
* Fixed: Contributors username in readme

= 1.4.0 =
* Added: External link field with customisable button text on notices and the frontend form

= 1.3.0 =
* Added: Dedicated Notice Board capabilities, separate from default post capabilities
* Added: Members Only option in the frontend submission form

= 1.1.0 =
* Added: Frontend notice submission form with role-based access control
* Added: Per-notice content restriction (Members Only toggle)
* Added: Customisable slugs for notices archive, categories, and tags
* Added: Customisable Back Button text and URL
* Added: Login redirect URL setting for restricted notices
* Added: Customisable locked notice message
* Added: Submission mode setting (Auto Publish / Save as Draft)
* Added: Dynamic role selector for frontend form access
* Added: Uninstall cleanup — removes all plugin data on deletion
* Added: Settings link on plugin list page
* Improved: Elementor widget now only loads if Elementor is active
* Improved: All inline scripts moved to enqueued files
* Improved: Full wp_unslash() on all $_POST and $_GET inputs
* Improved: Proper gmdate() usage instead of date()
* Fixed: Cron scheduling moved to activation hook

= 1.0.0 =
* Initial release
* Notice custom post type with categories and tags
* Pinned notices, urgent label, expiry date, PDF attachment
* List and grid layouts
* Search and filter bar
* Shortcode [noticeboard]
* Gutenberg block
* Elementor widget

== Upgrade Notice ==

= 1.4.1 =
Plugin renamed to Smitra Notice Board Manager. Existing settings and notices are preserved.

= 1.1.0 =
Major feature update. Adds frontend form, content restriction, customisable slugs, and back button settings. Recommended for all users.
