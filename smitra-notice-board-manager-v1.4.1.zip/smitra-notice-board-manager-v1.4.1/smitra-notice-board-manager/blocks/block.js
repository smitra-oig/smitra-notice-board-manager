( function( blocks, element, components, blockEditor, i18n ) {
    var el         = element.createElement;
    var __         = i18n.__;
    var InspectorControls = blockEditor.InspectorControls;
    var PanelBody  = components.PanelBody;
    var SelectControl = components.SelectControl;
    var RangeControl  = components.RangeControl;
    var ToggleControl = components.ToggleControl;
    var TextControl   = components.TextControl;

    blocks.registerBlockType( 'smitra-notice-board-manager/listing', {
        title: __( 'Notice Board', 'smitra-notice-board-manager' ),
        description: __( 'Display a list or grid of notices.', 'smitra-notice-board-manager' ),
        icon: 'megaphone',
        category: 'widgets',
        attributes: {
            layout:      { type: 'string',  default: 'list' },
            posts:       { type: 'number',  default: 10 },
            show_search: { type: 'string',  default: 'yes' },
            category:    { type: 'string',  default: '' },
        },

        edit: function( props ) {
            var attrs = props.attributes;

            return [
                el( InspectorControls, { key: 'inspector' },
                    el( PanelBody, { title: __( 'Notice Board Settings', 'smitra-notice-board-manager' ), initialOpen: true },
                        el( SelectControl, {
                            label:    __( 'Layout', 'smitra-notice-board-manager' ),
                            value:    attrs.layout,
                            options: [
                                { label: __( 'List', 'smitra-notice-board-manager' ),  value: 'list' },
                                { label: __( 'Grid', 'smitra-notice-board-manager' ),  value: 'grid' },
                            ],
                            onChange: function( val ) { props.setAttributes( { layout: val } ); }
                        } ),
                        el( RangeControl, {
                            label:    __( 'Number of Notices', 'smitra-notice-board-manager' ),
                            value:    attrs.posts,
                            min:      1,
                            max:      50,
                            onChange: function( val ) { props.setAttributes( { posts: val } ); }
                        } ),
                        el( SelectControl, {
                            label:    __( 'Show Search Bar', 'smitra-notice-board-manager' ),
                            value:    attrs.show_search,
                            options: [
                                { label: __( 'Yes', 'smitra-notice-board-manager' ), value: 'yes' },
                                { label: __( 'No', 'smitra-notice-board-manager' ),  value: 'no' },
                            ],
                            onChange: function( val ) { props.setAttributes( { show_search: val } ); }
                        } ),
                        el( TextControl, {
                            label:    __( 'Filter by Category Slug', 'smitra-notice-board-manager' ),
                            value:    attrs.category,
                            onChange: function( val ) { props.setAttributes( { category: val } ); }
                        } )
                    )
                ),
                el( 'div', { className: 'anbmwp-block-preview' },
                    el( 'div', { style: { padding: '20px', background: '#f9f9f9', border: '2px dashed #ccc', borderRadius: '8px', textAlign: 'center' } },
                        el( 'span', { style: { fontSize: '32px' } }, '📋' ),
                        el( 'p',    { style: { margin: '8px 0 4px', fontWeight: '600' } }, __( 'Notice Board', 'smitra-notice-board-manager' ) ),
                        el( 'p',    { style: { margin: 0, color: '#888', fontSize: '13px' } },
                            __( 'Layout: ', 'smitra-notice-board-manager' ) + attrs.layout + ' | ' +
                            __( 'Notices: ', 'smitra-notice-board-manager' ) + attrs.posts
                        )
                    )
                )
            ];
        },

        save: function() {
            return null; // Rendered server-side
        }
    } );

} )( window.wp.blocks, window.wp.element, window.wp.components, window.wp.blockEditor, window.wp.i18n );
