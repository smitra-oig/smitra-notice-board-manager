<?php
/**
 * Uninstall Handler
 *
 * Cleans up all plugin data when the plugin is deleted from WordPress.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 * @license GPL-2.0+
 */

// If uninstall is not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Remove custom Notice Board capabilities from all roles
$caps_to_remove = array(
	'edit_anbmwp_notices',
	'edit_others_anbmwp_notices',
	'publish_anbmwp_notices',
	'read_private_anbmwp_notices',
	'delete_anbmwp_notices',
	'delete_private_anbmwp_notices',
	'delete_published_anbmwp_notices',
	'delete_others_anbmwp_notices',
	'edit_private_anbmwp_notices',
	'edit_published_anbmwp_notices',
	'create_anbmwp_notices',
);

foreach ( wp_roles()->roles as $role_name => $role_info ) {
	$role = get_role( $role_name );
	if ( $role ) {
		foreach ( $caps_to_remove as $cap ) {
			$role->remove_cap( $cap );
		}
	}
}

// Delete plugin settings
delete_option( 'anbmwp_settings' );

// Remove scheduled cron
$timestamp = wp_next_scheduled( 'anbmwp_check_expiry' );
if ( $timestamp ) {
	wp_unschedule_event( $timestamp, 'anbmwp_check_expiry' );
}

// Delete all notice post meta
$notices = get_posts( array(
	'post_type'      => 'anbmwp_notice',
	'post_status'    => 'any',
	'posts_per_page' => -1,
	'fields'         => 'ids',
) );

foreach ( $notices as $notice_id ) {
	delete_post_meta( $notice_id, '_anbmwp_short_summary' );
	delete_post_meta( $notice_id, '_anbmwp_attachment' );
	delete_post_meta( $notice_id, '_anbmwp_expiry_date' );
	delete_post_meta( $notice_id, '_anbmwp_pinned' );
	delete_post_meta( $notice_id, '_anbmwp_urgent' );
	delete_post_meta( $notice_id, '_anbmwp_login_required' );
}

// Flush rewrite rules
flush_rewrite_rules();
