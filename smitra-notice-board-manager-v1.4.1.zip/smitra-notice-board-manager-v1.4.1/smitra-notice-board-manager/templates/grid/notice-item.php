<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<?php
$pinned      = get_post_meta( get_the_ID(), '_anbmwp_pinned', true );
$urgent      = get_post_meta( get_the_ID(), '_anbmwp_urgent', true );
$summary     = get_post_meta( get_the_ID(), '_anbmwp_short_summary', true );
$attachment  = get_post_meta( get_the_ID(), '_anbmwp_attachment', true );
$ext_link    = get_post_meta( get_the_ID(), '_anbmwp_external_link', true );
$link_btn    = get_post_meta( get_the_ID(), '_anbmwp_link_btn_text', true ) ?: __( 'Learn More', 'smitra-notice-board-manager' );
$expiry      = get_post_meta( get_the_ID(), '_anbmwp_expiry_date', true );
$categories  = get_the_terms( get_the_ID(), 'anbmwp_category' );
$login_req   = get_post_meta( get_the_ID(), '_anbmwp_login_required', true );
?>
<div class="anbmwp-item anbmwp-grid-item <?php echo $pinned ? 'anbmwp-pinned' : ''; ?> <?php echo $urgent ? 'anbmwp-urgent' : ''; ?>">
    <div class="anbmwp-grid-header">
        <div class="anbmwp-badges">
            <?php if ( $pinned ) : ?>
                <span class="anbmwp-badge anbmwp-badge-pin">📌 <?php _e( 'Pinned', 'smitra-notice-board-manager' ); ?></span>
            <?php endif; ?>
            <?php if ( $urgent ) : ?>
                <span class="anbmwp-badge anbmwp-badge-urgent">⚠ <?php _e( 'Urgent', 'smitra-notice-board-manager' ); ?></span>
            <?php endif; ?>
            <?php if ( $login_req === '1' ) : ?>
                <span class="anbmwp-badge anbmwp-badge-lock">🔒 <?php _e( 'Members Only', 'smitra-notice-board-manager' ); ?></span>
            <?php endif; ?>
        </div>
        <?php if ( $categories && ! is_wp_error( $categories ) ) : ?>
            <span class="anbmwp-grid-cat"><?php echo esc_html( $categories[0]->name ); ?></span>
        <?php endif; ?>
    </div>
    <div class="anbmwp-grid-body">
        <h3 class="anbmwp-item-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
        <?php if ( $summary ) : ?>
            <p class="anbmwp-item-summary"><?php echo esc_html( wp_trim_words( $summary, 20 ) ); ?></p>
        <?php endif; ?>
    </div>
    <div class="anbmwp-grid-footer">
        <span class="anbmwp-meta-date">🗓 <?php echo get_the_date(); ?></span>
        <?php if ( $expiry ) : ?>
            <span class="anbmwp-meta-expiry">⏳ <?php echo esc_html( date( 'd M Y', strtotime( $expiry ) ) ); ?></span>
        <?php endif; ?>
        <div class="anbmwp-grid-actions">
            <a href="<?php the_permalink(); ?>" class="anbmwp-btn anbmwp-btn-read"><?php _e( 'Read More', 'smitra-notice-board-manager' ); ?></a>
            <?php if ( $attachment ) : ?>
                <a href="<?php echo esc_url( $attachment ); ?>" class="anbmwp-btn anbmwp-btn-pdf" target="_blank" rel="noopener noreferrer">📎</a>
            <?php endif; ?>
            <?php if ( $ext_link ) : ?>
                <a href="<?php echo esc_url( $ext_link ); ?>" class="anbmwp-btn anbmwp-btn-link" target="_blank" rel="noopener noreferrer">🔗</a>
            <?php endif; ?>
        </div>
    </div>
</div>
