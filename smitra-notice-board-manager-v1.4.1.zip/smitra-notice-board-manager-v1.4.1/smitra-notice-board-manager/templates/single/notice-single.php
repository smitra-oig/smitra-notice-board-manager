<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<?php
$pinned          = get_post_meta( get_the_ID(), '_anbmwp_pinned', true );
$urgent          = get_post_meta( get_the_ID(), '_anbmwp_urgent', true );
$attachment      = get_post_meta( get_the_ID(), '_anbmwp_attachment', true );
$external_link   = get_post_meta( get_the_ID(), '_anbmwp_external_link', true );
$link_btn_text   = get_post_meta( get_the_ID(), '_anbmwp_link_btn_text', true ) ?: __( 'Learn More', 'smitra-notice-board-manager' );
$expiry          = get_post_meta( get_the_ID(), '_anbmwp_expiry_date', true );
$login_required  = get_post_meta( get_the_ID(), '_anbmwp_login_required', true );
$categories      = get_the_terms( get_the_ID(), 'anbmwp_category' );
$tags            = get_the_terms( get_the_ID(), 'anbmwp_tag' );
$is_locked       = ( $login_required === '1' && ! is_user_logged_in() );
$options         = get_option( 'nb_settings', [] );
$login_page      = ! empty( $options['login_page_url'] )   ? $options['login_page_url']   : wp_login_url( get_permalink() );
$locked_message  = ! empty( $options['locked_message'] )   ? $options['locked_message']   : __( 'This notice is for members only. Please log in to view the full content.', 'smitra-notice-board-manager' );
$back_btn_text   = ! empty( $options['back_button_text'] ) ? $options['back_button_text'] : __( '← Back to Notices', 'smitra-notice-board-manager' );
$back_btn_url    = ! empty( $options['back_button_url'] )  ? $options['back_button_url']  : get_post_type_archive_link( 'nb_notice' );
?>
<div class="anbmwp-single-notice">

    <!-- Header: always visible -->
    <div class="anbmwp-single-header">
        <div class="anbmwp-badges">
            <?php if ( $pinned ) : ?>
                <span class="anbmwp-badge anbmwp-badge-pin">📌 <?php _e( 'Pinned', 'smitra-notice-board-manager' ); ?></span>
            <?php endif; ?>
            <?php if ( $urgent ) : ?>
                <span class="anbmwp-badge anbmwp-badge-urgent">⚠ <?php _e( 'Urgent', 'smitra-notice-board-manager' ); ?></span>
            <?php endif; ?>
            <?php if ( $login_required === '1' ) : ?>
                <span class="anbmwp-badge anbmwp-badge-lock">🔒 <?php _e( 'Members Only', 'smitra-notice-board-manager' ); ?></span>
            <?php endif; ?>
            <?php if ( $categories && ! is_wp_error( $categories ) ) : ?>
                <?php foreach ( $categories as $cat ) : ?>
                    <span class="anbmwp-badge anbmwp-badge-cat"><?php echo esc_html( $cat->name ); ?></span>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Title always visible even if locked -->
        <h1 class="anbmwp-single-title"><?php the_title(); ?></h1>

        <div class="anbmwp-single-meta">
            <span>🗓 <?php echo get_the_date(); ?></span>
            <?php if ( $expiry ) : ?>
                <span>⏳ <?php printf( __( 'Expires: %s', 'smitra-notice-board-manager' ), esc_html( date( 'd M Y', strtotime( $expiry ) ) ) ); ?></span>
            <?php endif; ?>
        </div>
    </div>

    <?php if ( $is_locked ) : ?>

        <!-- Locked state -->
        <div class="anbmwp-locked-notice">
            <div class="anbmwp-locked-icon">🔒</div>
            <p class="anbmwp-locked-message"><?php echo esc_html( $locked_message ); ?></p>
            <a href="<?php echo esc_url( $login_page ); ?>" class="anbmwp-btn anbmwp-btn-login">
                <?php _e( 'Log In to View', 'smitra-notice-board-manager' ); ?>
            </a>
        </div>

    <?php else : ?>

        <!-- Full content -->
        <div class="anbmwp-single-content">
            <?php the_content(); ?>
        </div>

        <?php if ( $attachment ) : ?>
        <div class="anbmwp-single-attachment">
            <h4><?php _e( 'Attachment', 'smitra-notice-board-manager' ); ?></h4>
            <a href="<?php echo esc_url( $attachment ); ?>" class="anbmwp-btn anbmwp-btn-pdf" target="_blank" rel="noopener noreferrer">
                📎 <?php _e( 'Download Attachment', 'smitra-notice-board-manager' ); ?>
            </a>
        </div>
        <?php endif; ?>

        <?php if ( $external_link ) : ?>
        <div class="anbmwp-single-external-link">
            <a href="<?php echo esc_url( $external_link ); ?>" class="anbmwp-btn anbmwp-btn-link" target="_blank" rel="noopener noreferrer">
                🔗 <?php echo esc_html( $link_btn_text ); ?>
            </a>
        </div>
        <?php endif; ?>

        <?php if ( $tags && ! is_wp_error( $tags ) ) : ?>
        <div class="anbmwp-single-tags">
            <?php foreach ( $tags as $tag ) : ?>
                <a href="<?php echo esc_url( get_term_link( $tag ) ); ?>" class="anbmwp-tag"><?php echo esc_html( $tag->name ); ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

    <?php endif; ?>

    <!-- Back button: fully customisable from settings -->
    <div class="anbmwp-single-back">
        <a href="<?php echo esc_url( $back_btn_url ); ?>" class="anbmwp-btn anbmwp-btn-back">
            <?php echo esc_html( $back_btn_text ); ?>
        </a>
    </div>

</div>
