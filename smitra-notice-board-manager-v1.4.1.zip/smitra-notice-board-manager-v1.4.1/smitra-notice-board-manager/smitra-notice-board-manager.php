<?php
/**
 * Plugin Name:       Smitra Notice Board Manager
 * Plugin URI:        https://wordpress.org/plugins/smitra-notice-board-manager/
 * Description:       A professional notice board management system for WordPress. Create and manage pinned, urgent, and expiring notices with categories, tags, PDF attachments, frontend submission form, content restriction, shortcode, Gutenberg block, and Elementor widget support. Perfect for residential communities, schools, corporates, and any organisation that needs a structured notice board.
 * Version:           1.4.1
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Subhajit Mitra
 * Author URI:        https://profiles.wordpress.org/subhajit9836/
 * License:           GPL-2.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       smitra-notice-board-manager
 * Domain Path:       /languages
 *
 * @package           Smitra_Notice_Board_Manager
 * @author            Subhajit Mitra
 * @copyright         2025 Subhajit Mitra
 * @license           GPL-2.0+
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin Constants
define( 'ANBMWP_VERSION',     '1.4.1' );
define( 'ANBMWP_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'ANBMWP_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'ANBMWP_PLUGIN_FILE', __FILE__ );
define( 'ANBMWP_PLUGIN_BASE', plugin_basename( __FILE__ ) );

// Load core files
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-post-type.php';
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-meta-boxes.php';
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-shortcode.php';
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-block.php';
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-elementor.php';
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-expiry.php';
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-assets.php';
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-settings.php';
require_once ANBMWP_PLUGIN_DIR . 'includes/class-anbmwp-frontend-form.php';

/**
 * Initialize the plugin.
 *
 * @since 1.0.0
 */
function anbmwp_init() {
	// Load plugin text domain for translations
	load_plugin_textdomain(
		'smitra-notice-board-manager',
		false,
		dirname( ANBMWP_PLUGIN_BASE ) . '/languages'
	);

	ANBMWP_Post_Type::init();
	ANBMWP_Meta_Boxes::init();
	ANBMWP_Shortcode::init();
	ANBMWP_Block::init();
	ANBMWP_Expiry::init();
	ANBMWP_Assets::init();
	ANBMWP_Settings::init();
	ANBMWP_Frontend_Form::init();
}
add_action( 'plugins_loaded', 'anbmwp_init' );

/**
 * Plugin activation.
 *
 * @since 1.0.0
 */
function anbmwp_activate() {
	ANBMWP_Post_Type::register();
	ANBMWP_Post_Type::grant_caps_to_roles();
	// Set default options on first activation
	if ( ! get_option( 'anbmwp_settings' ) ) {
		update_option( 'anbmwp_settings', array(
			'notices_per_page'     => 10,
			'default_layout'       => 'list',
			'show_search'          => 1,
			'view_all_text'        => 'View All Notices',
			'no_notices_text'      => 'No notices found.',
			'back_button_text'     => '← Back to Notices',
			'back_button_url'      => '',
			'notice_slug'          => 'notices',
			'category_slug'        => 'notice-category',
			'tag_slug'             => 'notice-tag',
			'login_page_url'       => '',
			'locked_message'       => 'This notice is for members only. Please log in to view the full content.',
			'form_submission'      => 'draft',
			'form_allowed_roles'   => array( 'administrator', 'editor' ),
			'form_success_message' => 'Your notice has been submitted successfully.',
		) );
	}
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'anbmwp_activate' );

/**
 * Plugin deactivation.
 *
 * @since 1.0.0
 */
function anbmwp_deactivate() {
	// Clear scheduled cron
	$timestamp = wp_next_scheduled( 'anbmwp_check_expiry' );
	if ( $timestamp ) {
		wp_unschedule_event( $timestamp, 'anbmwp_check_expiry' );
	}
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'anbmwp_deactivate' );

/**
 * Add Settings link on plugin list page.
 *
 * @since 1.0.0
 */
function anbmwp_plugin_action_links( $links ) {
	$settings_link = '<a href="' . admin_url( 'edit.php?post_type=anbmwp_notice&page=anbmwp-settings' ) . '">' . esc_html__( 'Settings', 'smitra-notice-board-manager' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'anbmwp_plugin_action_links' );
