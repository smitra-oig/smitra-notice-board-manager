/**
 * Admin Meta Box Scripts
 * Handles media uploader for notice attachment field.
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 */
/* global wp */
jQuery( document ).ready( function( $ ) {
	$( '.anbmwp-upload-btn' ).on( 'click', function() {
		var target = $( this ).data( 'target' );
		var frame  = wp.media( {
			title:    'Select File',
			button:   { text: 'Use this file' },
			multiple: false
		} );
		frame.on( 'select', function() {
			var attachment = frame.state().get( 'selection' ).first().toJSON();
			$( '#' + target ).val( attachment.url );
		} );
		frame.open();
	} );
} );
