/**
 * Frontend Notice Submission Form
 *
 * @package Smitra_Notice_Board_Manager
 * @since   1.0.0
 */
/* global anbmwp_form */
jQuery( document ).ready( function( $ ) {
	$( '#anbmwp-submit-form' ).on( 'submit', function( e ) {
		e.preventDefault();

		var $form    = $( this );
		var $btn     = $( '#anbmwp-submit-btn' );
		var $spinner = $( '#anbmwp-form-spinner' );
		var $success = $( '#anbmwp-form-success' );
		var $error   = $( '#anbmwp-form-error' );

		$success.hide().text( '' );
		$error.hide().text( '' );
		$btn.prop( 'disabled', true );
		$spinner.show();

		var formData = new FormData( $form[0] );
		formData.append( 'action', 'anbmwp_submit_notice' );
		formData.append( 'anbmwp_form_nonce', anbmwp_form.nonce );

		$.ajax( {
			url:         anbmwp_form.ajax_url,
			type:        'POST',
			data:        formData,
			processData: false,
			contentType: false,
			success: function( response ) {
				$spinner.hide();
				$btn.prop( 'disabled', false );
				if ( response.success ) {
					$success.text( response.data.message ).show();
					$form[0].reset();
					$( 'html, body' ).animate( { scrollTop: $success.offset().top - 80 }, 400 );
				} else {
					$error.text( response.data.message ).show();
				}
			},
			error: function() {
				$spinner.hide();
				$btn.prop( 'disabled', false );
				$error.text( 'Something went wrong. Please try again.' ).show();
			}
		} );
	} );
} );
